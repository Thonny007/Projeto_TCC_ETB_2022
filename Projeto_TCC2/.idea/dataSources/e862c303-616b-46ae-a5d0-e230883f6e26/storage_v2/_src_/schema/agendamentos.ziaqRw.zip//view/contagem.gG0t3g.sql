create definer = root@localhost view contagem as
select `a`.`status_agnd` AS `status_agnd`, count(0) AS `quantidade`
from `agendamentos`.`agendamento` `a`
group by `a`.`status_agnd`;

